#include <GL\glut.h>
#include <math.h>
#include <stdlib.h>
#include <iostream>

void PlaneBody()
{
    GLUquadricObj *pObj;
    pObj = gluNewQuadric();
    gluQuadricNormals(pObj, GLU_SMOOTH);
    glColor3f(1,1,1);

    glPushMatrix();
    gluCylinder(pObj, 1.0f, 1.0f, 10.0f, 26, 13);
    glTranslatef(0,0,10);
    gluDisk(pObj, 0, 1.0, 26, 13);
    glColor3f(0.5,0.5,0.5);
    gluCylinder(pObj, 0.5f, 0.5f, 0.5f, 26, 13);
    glColor3f(1,0,0);
    glTranslatef(0,0,0.5);
    gluDisk(pObj, 0, 0.5, 26, 13);
    glPopMatrix();

    glPushMatrix();
    glColor3f(0.5,0.5,0.5);
    glScalef(1,1,3);
    gluSphere(pObj, 1.0f, 26, 26);

    glPopMatrix();

    glPushMatrix();
    glColor3f(0.5,0.5,0.5);
    glScalef(1,1,3);
    gluSphere(pObj, 1.0f, 26, 26);

    glPopMatrix();
    gluDeleteQuadric(pObj);
}

void wing()
{
    glBegin(GL_QUADS);
    glColor3f(1,0,0);
    glVertex3f(0,4,0);
    glVertex3f(7,1,12);
    glVertex3f(9,1,12);
    glVertex3f(8,4,0);

    glVertex3f(0,0,0);
    glVertex3f(7,0,12);
    glVertex3f(9,0,12);
    glVertex3f(8,0,0);

    glColor3f(0,0,1);
    glVertex3f(0,4,0);
    glVertex3f(0,0,0);
    glVertex3f(7,0,12);
    glVertex3f(7,1,12);

    glVertex3f(7,1,12);
    glVertex3f(7,0,12);
    glVertex3f(9,0,12);
    glVertex3f(9,1,12);

    glVertex3f(8,0,0);
    glVertex3f(8,4,0);
    glVertex3f(9,1,12);
    glVertex3f(9,0,12);
    glEnd();
}
void LeftNRightWing()
{
    glPushMatrix();
    glTranslatef(0,-0.8,0);
    glRotatef(-90,0,1,0);
    glScalef(0.5,0.4,1);
    wing();

    glTranslatef(10,0,0);
    glScalef(0.8,1,0.5);
    wing();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,-0.8,0);
    glRotatef(-90,0,1,0);
    glScalef(0.5,0.4,-1);
    wing();

    glTranslatef(10,0,0);
    glScalef(0.8,1,0.5);
    wing();
    glPopMatrix();
}
void TopWing()
{
    glPushMatrix();
    glTranslatef(0.6,0.5,7.5);
    glRotatef(-90, 0,1,0);
    glScalef(0.3, 0.3,0.3);
    glBegin(GL_QUADS);
    glColor3f(0,0,1);
    glVertex3f(2,7,2);
    glVertex3f(0,0,4);
    glVertex3f(8,0,4);
    glVertex3f(6,7,2);

    glVertex3f(2,7,2);
    glVertex3f(0,0,0);
    glVertex3f(8,0,0);
    glVertex3f(6,7,2);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3f(1,0,0);
    glVertex3f(2,7,2);
    glVertex3f(0,0,0);
    glVertex3f(0,0,4);

    glVertex3f(6,7,2);
    glVertex3f(8,0,0);
    glVertex3f(8,0,4);
    glEnd();
    glPopMatrix();
}
void plane()
{
    glRotatef(180,0,1,0);
    PlaneBody();
    LeftNRightWing();//Add code here
    TopWing();
}
