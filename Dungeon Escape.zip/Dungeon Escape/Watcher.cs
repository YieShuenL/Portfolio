﻿using GAlgoT2430.Engine;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MonoGame.Extended.Tiled;
using MonoGame.Extended.Content;
using GAlgoT2430.AI;
using MonoGame.Extended.Graphics;
using System.Diagnostics;
using System;
using System.Collections.Generic;
using static DungeonGame.Guard;

namespace DungeonGame
{
    public class Watcher : AnimationGameObject
    {
        public float MaxSpeed;
        public int StartColumn;
        public int StartRow;
        public TiledMap TiledMap;
        public TileGraph TileGraph;
        public HCFSM FSM;

        private Player _player;
        private SpriteEffects _spriteEffects = SpriteEffects.None; // To flip animated sprite
        private Direction _lastDirection = Direction.Right; // Default to Right for initial state
        private readonly Guard[] _guardsToAlert; // Guards to alert when player is detected

        // Circle visualization for alert radius
        private Texture2D _circleTexture;
        private const int AlertRadiusInTiles = 8;
        private int _circleRadius;

        public Watcher(Guard[] guardsToAlert = null) : base( "enemy.sf")
        {
            _guardsToAlert = guardsToAlert ?? FindNearbyGuards(); // Initialize guards to alert
        }


        public override void Initialize()
        {
            GameMap gameMap = (GameMap)GameObjectCollection.FindByName("GameMap");
            TiledMap = gameMap.TiledMap;
            TileGraph = gameMap.TileGraph;
            MaxSpeed = 50.0f;

            Tile startTile = new Tile(StartColumn, StartRow);
            if (!TileGraph.Nodes.Contains(startTile))
            {
                startTile = FindNearestNavigableTile(StartColumn, StartRow);
                Debug.WriteLine($"Start tile ({StartColumn}, {StartRow}) not navigable. Moved to {startTile}");
            }
            Position = Tile.ToPosition(startTile, TiledMap.TileWidth, TiledMap.TileHeight);

            AnimatedSprite.SetAnimation("watcher_idleRight");
            AnimatedSprite.TextureRegion = SpriteSheet.TextureAtlas[AnimatedSprite.Controller.CurrentFrame];
            Origin = new Vector2(0, AnimatedSprite.TextureRegion.Bounds.Height / 2);

            // Initialize Player reference and FSM
            _player = (Player)GameObjectCollection.FindByName("Player");
            FSM = new WatcherHCFSM(_game, this, TiledMap, TileGraph, _player, _guardsToAlert);
            FSM.Initialize();

            // Initialize alert radius circle
            _circleRadius = TiledMap.TileWidth * AlertRadiusInTiles;
            GenerateCircleTexture();
        }

        public override void Update()
        {
            FSM.Update();
            AnimatedSprite.Update(ScalableGameTime.GameTime);
        }

        public override void Draw()
        {
            _game.SpriteBatch.Begin();

            // Draw the alert radius circle
            Vector2 circlePosition = Position - new Vector2(_circleRadius, _circleRadius);
            Rectangle destinationRectangle = new Rectangle(
                (int)circlePosition.X,
                (int)circlePosition.Y,
                _circleRadius * 2,
                _circleRadius * 2
            );
            _game.SpriteBatch.Draw(_circleTexture, destinationRectangle, Color.Red * 0.3f); // Red circle with 30% opacity

            // Draw the animated sprite
            _game.SpriteBatch.Draw(
                texture: AnimatedSprite.TextureRegion.Texture,
                position: Position,
                sourceRectangle: AnimatedSprite.TextureRegion.Bounds,
                color: Color.White,
                rotation: Orientation,
                origin: Origin,
                scale: Scale,
                effects: _spriteEffects,
                layerDepth: 0f
            );

            _game.SpriteBatch.End();
        }

        public Vector2 Move(Vector2 src, Vector2 dest, float elapsedSeconds)
        {
            Vector2 dP = dest - src;
            float distance = dP.Length();
            float step = MaxSpeed * elapsedSeconds;

            if (step < distance)
            {
                dP.Normalize();
                return src + (dP * step);
            }
            else
            {
                return dest;
            }
        }

        public void UpdateAnimatedSprite(Tile currentTile, Tile nextTile)
        {
            if (currentTile == null || nextTile == null)
            {
                throw new ArgumentNullException("UpdateAnimatedSprite(): currentTile or nextTile is null.");
            }

            // Determine if moving (based on nextTile vs. currentTile)
            int rowDiff = nextTile.Row - currentTile.Row;
            int colDiff = nextTile.Col - currentTile.Col;

            string animationName;
            if (rowDiff == 0 && colDiff == 0) // No movement (same tile)
            {
                animationName = "watcher_idleRight"; // Default to right, will flip if needed
                _spriteEffects = _lastDirection == Direction.Left ? SpriteEffects.FlipHorizontally : SpriteEffects.None; // Use last direction for idle
            }
            else // Movement
            {
                if (rowDiff == 0) // Horizontal movement
                {
                    if (colDiff > 0) // Right
                    {
                        animationName = "watcher_runRight";
                        _spriteEffects = SpriteEffects.None;
                    }
                    else // Left (flip Right)
                    {
                        animationName = "watcher_runRight";
                        _spriteEffects = SpriteEffects.FlipHorizontally;
                    }
                }
                else // Vertical movement
                {
                    if (rowDiff > 0) // Down
                    {
                        animationName = "watcher_runDown";
                    }
                    else // Up
                    {
                        animationName = "watcher_runUp";
                    }
                    // Maintain last horizontal flip state for vertical movement (no flip)
                    _spriteEffects = _lastDirection == Direction.Left ? SpriteEffects.FlipHorizontally : SpriteEffects.None; // Use last horizontal direction
                }
            }

            if (AnimatedSprite.CurrentAnimation != animationName)
            {
                AnimatedSprite.SetAnimation(animationName);
                AnimatedSprite.TextureRegion = SpriteSheet.TextureAtlas[AnimatedSprite.Controller.CurrentFrame];
            }
        }

        public void SetLastDirection(Direction direction)
        {
            _lastDirection = direction; // Update last movement direction
        }

        private Tile FindNearestNavigableTile(int col, int row)
        {
            for (int r = 0; r < TiledMap.Height; r++)
            {
                for (int c = 0; c < TiledMap.Width; c++)
                {
                    Tile tile = new Tile(c, r);
                    if (TileGraph.Nodes.Contains(tile))
                    {
                        return tile;
                    }
                }
            }
            throw new Exception("No navigable tiles found in the map!");
        }

        // Generate a circular texture for the alert radius
        private void GenerateCircleTexture()
        {
            int diameter = _circleRadius * 2;
            _circleTexture = new Texture2D(_game.GraphicsDevice, diameter, diameter);
            Color[] colorData = new Color[diameter * diameter];
            Vector2 center = new Vector2(_circleRadius, _circleRadius);

            for (int y = 0; y < diameter; y++)
            {
                for (int x = 0; x < diameter; x++)
                {
                    Vector2 pos = new Vector2(x, y);
                    float distance = Vector2.Distance(center, pos);
                    colorData[y * diameter + x] = (distance <= _circleRadius) ? Color.White : Color.Transparent;
                }
            }

            _circleTexture.SetData(colorData);
        }

        public float GetAlertRadius()
        {
            return _circleRadius;
        }

        private Guard[] FindNearbyGuards()
        {
            List<Guard> nearbyGuards = new List<Guard>();

            foreach (var obj in GameObjectCollection.Objects.Values)
            {
                if (obj is Guard guard)
                {
                    // Find nearby guards within alert radius
                    float distance = Vector2.Distance(Position, guard.Position);
                    if (distance <= GetAlertRadius()) // Check alert radius
                    {
                        nearbyGuards.Add(guard);
                        Debug.WriteLine($"Guard {guard.Name} is within alert range!");
                    }
                }
            }

            return nearbyGuards.ToArray();
        }


    }
}