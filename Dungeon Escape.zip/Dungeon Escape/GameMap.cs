﻿using GAlgoT2430.Engine;
using MonoGame.Extended.Tiled.Renderers;
using MonoGame.Extended.Tiled;

namespace DungeonGame
{
    public class GameMap : GameObject
    {
        public TiledMap TiledMap { get; private set; }
        public TiledMapRenderer TiledMapRenderer { get; private set; }
		
        public TileGraph TileGraph { get; private set; }

        // Defines the row and column of any navigable tile to construct the tile graph
        public ushort StartColumn;
        public ushort StartRow;

        public GameMap(string name) : base(name)
        {
        }

		public override void LoadContent()
        {
            TiledMap = _game.Content.Load<TiledMap>("dungeon3");
        }

        public override void Initialize()
        {
            // Initialize tiled map renderer
            TiledMapRenderer = new TiledMapRenderer(_game.GraphicsDevice, TiledMap);

            // Get the Floor layer from the tiled map (Changed from Food layer of Pacman game)
            TiledMapTileLayer walkLayer = TiledMap.GetLayer<TiledMapTileLayer>("Floor");

            TileGraph = new TileGraph();
            TileGraph.CreateFromTiledMapTileLayer(walkLayer, StartColumn, StartRow);            
        }

        public override void Update()
        {
            TiledMapRenderer.Update(ScalableGameTime.GameTime);
        }

        public override void Draw()
        {
            TiledMapRenderer.Draw();
        }
    }
}
