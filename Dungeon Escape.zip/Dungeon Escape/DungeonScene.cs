﻿using GAlgoT2430.Engine;

namespace DungeonGame
{
    public class DungeonScene: GameScene
    {
        public override void CreateScene()
        {
            // Game map
            GameMap gameMap = new GameMap("GameMap");
            gameMap.StartColumn = 25;
            gameMap.StartRow = 15;

            // Create five Guard NPCs
            Guard guard1 = new Guard();
            guard1.StartColumn = 10;
            guard1.StartRow = 40;
            
            Guard guard2 = new Guard();
            guard2.StartColumn = 9;
            guard2.StartRow = 2;
            
            Guard guard3 = new Guard();
            guard3.StartColumn = 33;
            guard3.StartRow = 42;
            
            Guard guard4 = new Guard();
            guard4.StartColumn = 25;
            guard4.StartRow = 6;
            
            Guard guard5 = new Guard();
            guard5.StartColumn = 37;
            guard5.StartRow = 14;

            // Create two Watcher NPCs
            Watcher watcher1 = new Watcher();
            watcher1.StartColumn = 27;
            watcher1.StartRow = 27;
            
            Watcher watcher2 = new Watcher();
            watcher2.StartColumn = 40;
            watcher2.StartRow = 26;

            // Player character
            Player player = new Player();
            player.StartColumn = 48;
            player.StartRow = 1;
            player.NavigableTileLayerName = "Floor";
        }
    }
}
