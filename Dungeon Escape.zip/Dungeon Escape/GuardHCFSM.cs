﻿using GAlgoT2430.AI;
using GAlgoT2430.Engine;
using Microsoft.Xna.Framework;
using MonoGame.Extended.Tiled;
using System.Collections.Generic;
using System.Diagnostics;

namespace DungeonGame
{
    public class GuardHCFSM : HCFSM
    {
        public enum State { Roam, Chase, AlertChase }
        public State CurrentState;

        private GameEngine _game;
        private Guard _guard;
        private TiledMap _tiledMap;
        private TileGraph _tileGraph;

        private Tile _srcTile;
        private Tile _destTile;
        private LinkedList<Tile> _path;

        // For Roam State
        private Vector2 _destTilePosition;

        // For Chase/AlertChase States
        private Player _player;
        private Tile _nextTile;
        private Vector2 _nextTilePosition;
        private float _chaseOutsideRadiusSeconds; // For going back to Roam after losing track of Player
        private const float ChaseOutsideRadiusTime = 2.0f; // Constant for the timer above
                
        private float _alertChaseWaitSeconds; // For AlertChase delay before going back to Roam
        private const float AlertChaseWaitTime = 3.0f;

        public GuardHCFSM(GameEngine game, Guard guard, TiledMap map, TileGraph graph, Player player)
        {
            _path = new LinkedList<Tile>();
            _game = game;
            _guard = guard;
            _tiledMap = map;
            _tileGraph = graph;
            _player = player;
        }

        public override void Initialize()
        {
            CurrentState = State.Roam;
            Roam_Initialize();
        }

        public override void Update()
        {
            switch (CurrentState)
            {
                case State.Roam:
                    Roam_Action();
                    break;
                case State.Chase:
                    Chase_Action();
                    break;
                case State.AlertChase:
                    AlertChase_Action();
                    break;
            }

            // If caught Player then game manager set game state to Lose
            float overlapRadius = 20f;
            float distance = Vector2.Distance(_guard.Position, _player.Position);
            if (distance <= overlapRadius) 
            {
                GameManager gameManager = _game.GameManager;
                gameManager.SetState(GameManager.GameState.Lose, "You Lose!");
            }
        }

        #region Roam State Methods
        private void Roam_Initialize()
        {
            _guard.MaxSpeed = 80.0f;
            _srcTile = Tile.ToTile(_guard.Position, _tiledMap.TileWidth, _tiledMap.TileHeight);
        }

        private void Roam_Action()
        {
            if (Roam_IsPathEmpty())
            {
                _srcTile = Tile.ToTile(_guard.Position, _tiledMap.TileWidth, _tiledMap.TileHeight);
                _path = Roam_GenerateRandomPath(_tileGraph, _srcTile);
                if (_path != null && _path.Count > 0) _path.RemoveFirst();
                else
                {
                    Debug.WriteLine("Failed to generate roam path!");
                    return;
                }
                _destTile = _path.Last.Value;
                _destTilePosition = Tile.ToPosition(_destTile, _tiledMap.TileWidth, _tiledMap.TileHeight);
                Tile nextTile = _path.First.Value;
                UpdateGuardDirectionAndAnimation(_srcTile, nextTile);
            }
            Roam_Moving();
            CheckPlayerDetection();
        }

        private bool Roam_IsPathEmpty()
        {
            return _path == null || _path.Count == 0;
        }

        private LinkedList<Tile> Roam_GenerateRandomPath(TileGraph graph, Tile srcTile)
        {
            Tile randomTile = new Tile(-1, -1);

            // Try to find a random tile with maximum 10 attempts, if failed return null
            int attempts = 0;
            while (!_tileGraph.Nodes.Contains(randomTile) || randomTile.Equals(srcTile))
            {
                randomTile.Col = _game.Random.Next(0, _tiledMap.Width);
                randomTile.Row = _game.Random.Next(0, _tiledMap.Height);
                attempts++;
                if (attempts > 10)
                {
                    return null;
                }
            }
            return AStar.Compute(_tileGraph, srcTile, randomTile, AStarHeuristic.EuclideanSquared);
        }

        private void Roam_Moving()
        {
            float elapsedSeconds = ScalableGameTime.DeltaTime;
            Tile headTile = _path.First.Value;
            Vector2 headTilePosition = Tile.ToPosition(headTile, _tiledMap.TileWidth, _tiledMap.TileHeight);

            if (_guard.Position.Equals(headTilePosition))
            {
                //Debug.WriteLine($"Roam: Reached tile (Col = {headTile.Col}, Row = {headTile.Row})");
                _path.RemoveFirst();
                if (!Roam_IsPathEmpty())
                {
                    Tile nextTile = _path.First.Value;
                    UpdateGuardDirectionAndAnimation(headTile, nextTile);
                }
            }
            _guard.Position = _guard.Move(_guard.Position, headTilePosition, elapsedSeconds);
        }
        #endregion

        #region Chase State Methods (Player Detection)
        private void Chase_Initialize()
        {
            _guard.MaxSpeed = 100.0f;
            _srcTile = Tile.ToTile(_guard.Position, _tiledMap.TileWidth, _tiledMap.TileHeight);
            _destTile = Tile.ToTile(_player.Position, _tiledMap.TileWidth, _tiledMap.TileHeight);
            _path = AStar.Compute(_tileGraph, _srcTile, _destTile, AStarHeuristic.EuclideanSquared);
            if (_path != null && _path.Count > 0)
            {
                _path.RemoveFirst();
                if (_path.Count > 0)
                {
                    _nextTile = _path.First.Value;
                    _nextTilePosition = Tile.ToPosition(_nextTile, _tiledMap.TileWidth, _tiledMap.TileHeight);
                    UpdateGuardDirectionAndAnimation(_srcTile, _nextTile);
                }
                else
                {
                    _nextTile = _destTile;
                    _nextTilePosition = _guard.Position; // Already reached Player position, no more path
                }
            }
            else
            {
                Debug.WriteLine("Chase_Initialize: Failed to compute initial path to player!");
                _nextTilePosition = _guard.Position;
                _nextTile = _srcTile;
            }
            _chaseOutsideRadiusSeconds = ChaseOutsideRadiusTime; // Reset timer
        }

        private void Chase_Action()
        {
            float elapsedSeconds = ScalableGameTime.DeltaTime;
            Vector2 playerPosition = _player.Position;
            float playerRadius = _player.CircleRadius;
            Vector2 guardPosition = _guard.Position;
            float distance = Vector2.Distance(guardPosition, playerPosition);

            if (distance <= playerRadius)
            {
                _chaseOutsideRadiusSeconds = ChaseOutsideRadiusTime;
                if (_guard.Position.Equals(_nextTilePosition))
                {
                    if (Chase_ShouldRecalculatePathTowardsPlayer())
                    {
                        Chase_RecalculatePathTowardsPlayer();
                    }
                    else if (_path != null && _path.Count > 0)
                    {
                        _srcTile = _nextTile;
                        _path.RemoveFirst();
                        if (_path.Count > 0)
                        {
                            _nextTile = _path.First.Value;
                            _nextTilePosition = Tile.ToPosition(_nextTile, _tiledMap.TileWidth, _tiledMap.TileHeight);
                            UpdateGuardDirectionAndAnimation(_srcTile, _nextTile);
                        }
                    }
                }
            }
            else
            {
                _chaseOutsideRadiusSeconds -= elapsedSeconds;
                if (_chaseOutsideRadiusSeconds <= 0)
                {
                    Roam_Initialize();
                    CurrentState = State.Roam; // Lost track of Player, switch to Roam state
                    return;
                }
                else if (_guard.Position.Equals(_nextTilePosition) && _path != null && _path.Count > 0)
                {
                    _srcTile = _nextTile;
                    _path.RemoveFirst();
                    if (_path.Count > 0)
                    {
                        _nextTile = _path.First.Value;
                        _nextTilePosition = Tile.ToPosition(_nextTile, _tiledMap.TileWidth, _tiledMap.TileHeight);
                        UpdateGuardDirectionAndAnimation(_srcTile, _nextTile);
                    }
                }
            }
            _guard.Position = _guard.Move(_guard.Position, _nextTilePosition, elapsedSeconds);
        }

        private bool Chase_ShouldRecalculatePathTowardsPlayer()
        {
            Tile currentPlayerTile = Tile.ToTile(_player.Position, _tiledMap.TileWidth, _tiledMap.TileHeight);
            return _path == null || _path.Count == 0 || !_path.Contains(currentPlayerTile);
        }

        private void Chase_RecalculatePathTowardsPlayer()
        {
            _srcTile = Tile.ToTile(_guard.Position, _tiledMap.TileWidth, _tiledMap.TileHeight);
            _destTile = Tile.ToTile(_player.Position, _tiledMap.TileWidth, _tiledMap.TileHeight);
            _path.Clear();
            _path = AStar.Compute(_tileGraph, _srcTile, _destTile, AStarHeuristic.EuclideanSquared);
            if (_path != null && _path.Count > 0)
            {
                _path.RemoveFirst();
                if (_path.Count > 0)
                {
                    _nextTile = _path.First.Value;
                    _nextTilePosition = Tile.ToPosition(_nextTile, _tiledMap.TileWidth, _tiledMap.TileHeight);
                    UpdateGuardDirectionAndAnimation(_srcTile, _nextTile);
                }
            }
            else
            {
                Debug.WriteLine("Chase_RecalculatePath: Failed to compute path to player!");
            }
        }
        #endregion

        #region AlertChase State Methods (Watcher Target)
        private void AlertChase_Initialize()
        {
            _guard.MaxSpeed = 100.0f;
            _srcTile = Tile.ToTile(_guard.Position, _tiledMap.TileWidth, _tiledMap.TileHeight);
            _path = AStar.Compute(_tileGraph, _srcTile, _destTile, AStarHeuristic.EuclideanSquared);
            if (_path != null && _path.Count > 0)
            {
                _path.RemoveFirst();
                if (_path.Count > 0)
                {
                    _nextTile = _path.First.Value;
                    _nextTilePosition = Tile.ToPosition(_nextTile, _tiledMap.TileWidth, _tiledMap.TileHeight);
                    UpdateGuardDirectionAndAnimation(_srcTile, _nextTile);
                }
                else
                {
                    // If already reached Watcher's position
                    _nextTile = _destTile;
                    _nextTilePosition = Tile.ToPosition(_destTile, _tiledMap.TileWidth, _tiledMap.TileHeight);
                }
            }
            else
            {
                _nextTilePosition = _guard.Position;
                _nextTile = _srcTile;
                Debug.WriteLine("AlertChase_Initialize: Failed to compute path to Watcher or already there!");
            }
            _alertChaseWaitSeconds = 0f;
        }

        private void AlertChase_Action()
        {
            float elapsedSeconds = ScalableGameTime.DeltaTime;

            // Check if Player is in range while moving in alerted state
            if (Vector2.Distance(_guard.Position, _player.Position) <= _player.CircleRadius)
            {
                Chase_Initialize();
                CurrentState = State.Chase;
                return;
            }

            if (_guard.Position.Equals(_nextTilePosition))
            {
                if (_path == null || _path.Count == 0)
                {
                    // Lost track of Player, start timer
                    if (_alertChaseWaitSeconds == 0f)
                    {
                        _alertChaseWaitSeconds = AlertChaseWaitTime;
                    }
                    else
                    {
                        _alertChaseWaitSeconds -= elapsedSeconds;
                        if (_alertChaseWaitSeconds <= 0)
                        {
                            // Found Player again, switch to Chase
                            if (Vector2.Distance(_guard.Position, _player.Position) <= _player.CircleRadius)
                            {
                                Chase_Initialize();
                                CurrentState = State.Chase;
                            }
                            // Player not found anymore, switch to Roam
                            else
                            {
                                Roam_Initialize();
                                CurrentState = State.Roam;
                            }
                        }
                    }
                    return;
                }

                _srcTile = _nextTile;
                _path.RemoveFirst();
                if (_path.Count > 0)
                {
                    _nextTile = _path.First.Value;
                    _nextTilePosition = Tile.ToPosition(_nextTile, _tiledMap.TileWidth, _tiledMap.TileHeight);
                    UpdateGuardDirectionAndAnimation(_srcTile, _nextTile);
                }
                else
                {
                    _alertChaseWaitSeconds = AlertChaseWaitTime;
                }
            }
            else
            {
                _guard.Position = _guard.Move(_guard.Position, _nextTilePosition, elapsedSeconds);
            }
        }
        #endregion

        #region Detection and External Control
        private void CheckPlayerDetection()
        {
            float distance = Vector2.Distance(_guard.Position, _player.Position);
            // Detected Player, change to Chase
            if (distance <= _player.CircleRadius)
            {
                Chase_Initialize();
                CurrentState = State.Chase;
            }
        }

        public Tile GetNextTile()
        {
            if ((CurrentState == State.Roam || CurrentState == State.Chase || CurrentState == State.AlertChase) &&
                _path != null && _path.Count > 0)
            {
                return _path.First.Value;
            }
            return null;
        }

        public LinkedList<Tile> GetPath()
        {
            return _path;
        }

        public void SetNewTarget(Tile alertPosition)
        {
            if (CurrentState == State.Chase)
            {
                // Already chasing Player, no need to set new target
                return;
            }
            if (CurrentState == State.AlertChase)
            {
                // Already in alert about to chase Player, no need to set new target
                return;
            }
            if (CurrentState == State.Roam)
            {
                // Alerted while roaming, go to the alerted position
                _destTile = alertPosition;
                ForceChaseToPosition(alertPosition);
            }
        }

        public void ForceChaseToPosition(Tile targetTile)
        {
            _destTile = targetTile;
            _path = AStar.Compute(_tileGraph, Tile.ToTile(_guard.Position, _tiledMap.TileWidth, _tiledMap.TileHeight), _destTile, AStarHeuristic.Manhattan);

            if (_path != null && _path.Count > 0)
            {
                _path.RemoveFirst();
                AlertChase_Initialize();
                CurrentState = State.AlertChase;
            }
            else
            {
                // If Guard is already at alerted position
                _destTile = targetTile;
                _nextTilePosition = _guard.Position;
                _nextTile = Tile.ToTile(_guard.Position, _tiledMap.TileWidth, _tiledMap.TileHeight);
                CurrentState = State.AlertChase;
                _alertChaseWaitSeconds = AlertChaseWaitTime; // Start wait immediately
            }
        }

        private void UpdateGuardDirectionAndAnimation(Tile currentTile, Tile nextTile)
        {
            int rowDiff = nextTile.Row - currentTile.Row;
            int colDiff = nextTile.Col - currentTile.Row;

            Guard.Direction direction = Guard.Direction.None;
            if (rowDiff == 0)
            {
                if (colDiff > 0) direction = Guard.Direction.Right;
                else if (colDiff < 0) direction = Guard.Direction.Left;
            }
            else if (colDiff == 0)
            {
                if (rowDiff > 0) direction = Guard.Direction.Down;
                else if (rowDiff < 0) direction = Guard.Direction.Up;
            }

            _guard.UpdateAnimatedSprite(currentTile, nextTile);
            _guard.SetLastDirection(direction);
        }
        #endregion
    }
}