﻿using GAlgoT2430.Engine;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGame.Extended.Tiled;
using System;

namespace DungeonGame
{
    public class Player : AnimationGameObject
    {
        public float Speed;
        // Constants for walk and run speed
        private const float _walkSpeed = 80.0f;
        private const float _runSpeed = 120.0f;

        public int StartColumn;
        public int StartRow;
        public string NavigableTileLayerName;

        private bool _isRunning = false;
        private KeyboardState _prevKeyboardState;
        private int _tileSize = 16; // Map tile size
        private Direction _currentDirection = Direction.None;
        private Direction _prevDirection = Direction.None;
        private bool _isMoving = false;

        private enum Direction { None, Up, Down, Left, Right }

        private Tile _currentTile;
        private Vector2 _nextTilePosition;

        private TiledMap _tiledMap;
        private TiledMapTileLayer _navigableLayer;

        private Texture2D _circleTexture; // Visualize detection radius
        private int _circleRadius;

        private SpriteEffects _spriteEffects = SpriteEffects.None; // To flip animated sprite

        public bool IsRunning => _isRunning;
        public int CircleRadius => _circleRadius;

        public Player() : base("Player", "hero.sf")
        {
        }

        public override void Initialize()
        {
            _currentDirection = Direction.None;
            _prevDirection = Direction.None;

            GameMap gameMap = (GameMap)GameObjectCollection.FindByName("GameMap");
            _tiledMap = gameMap.TiledMap;
            _navigableLayer = _tiledMap.GetLayer<TiledMapTileLayer>(NavigableTileLayerName);

            _currentTile = new Tile(StartColumn, StartRow);

            // Position at the center of the starting tile, adjusted for 16x16 sprite
            Position = Tile.ToPosition(_currentTile, _tiledMap.TileWidth, _tiledMap.TileHeight) + new Vector2(_tileSize / 2, _tileSize / 2);
            _nextTilePosition = Position;

            AnimatedSprite.SetAnimation("player_idleRight"); // Initialize to idle animation
            AnimatedSprite.TextureRegion = SpriteSheet.TextureAtlas[AnimatedSprite.Controller.CurrentFrame];
            Origin = new Vector2(AnimatedSprite.TextureRegion.Bounds.Width / 2, AnimatedSprite.TextureRegion.Bounds.Height / 2);

            Speed = _walkSpeed; // Initialize to walking speed
            _circleRadius = _tileSize * 3; // Initialize detection radius (will change based on tile size)
            GenerateCircleTexture();
        }

        public override void Update()
        {
            // Added keyboard state for press and release key to move Player
            KeyboardState keyboardState = Keyboard.GetState();

            // Toggle between walking and running when "C" is pressed
            if (keyboardState.IsKeyDown(Keys.C) && _prevKeyboardState.IsKeyUp(Keys.C))
            {
                _isRunning = !_isRunning;
                Speed = _isRunning ? _runSpeed : _walkSpeed;
                _circleRadius = _tileSize * (_isRunning ? 5 : 3); // Update radius
            }

            _prevKeyboardState = keyboardState;

            Direction newDirection = GetDirectionFromInput();
            UpdateDirection(newDirection);

            if (_isMoving && Position.Equals(_nextTilePosition))
            {
                _currentTile = Tile.ToTile(Position, _tiledMap.TileWidth, _tiledMap.TileHeight);

                Tile nextTile = _currentTile;
                Direction[] directions = { _currentDirection, _prevDirection };

                foreach (Direction direction in directions)
                {
                    nextTile = GetNextTileFromDirection(direction);
                    ushort col = (ushort)nextTile.Col;
                    ushort row = (ushort)nextTile.Row;

                    if (_navigableLayer.TryGetTile(col, row, out TiledMapTile? nextTiledMapTile))
                    {
                        if (!nextTiledMapTile.Value.IsBlank)
                        {
                            if (direction == _currentDirection)
                                _prevDirection = Direction.None;
                            break;
                        }
                        else
                        {
                            nextTile = _currentTile;
                        }
                    }
                }

                UpdateAnimatedSprite(_currentTile, nextTile);

                if (!nextTile.Equals(_currentTile))
                {
                    _nextTilePosition = Tile.ToPosition(nextTile, _tiledMap.TileWidth, _tiledMap.TileHeight) + new Vector2(_tileSize / 2, _tileSize / 2 - 8); // Adjust for 16x32 sprite
                    _isMoving = true;
                }
                else
                {
                    _isMoving = false;
                    _currentDirection = Direction.None;
                    _prevDirection = Direction.None;
                    AnimatedSprite.SetAnimation("player_idleRight"); // Stop moving, use idle animation
                }
            }

            if (_isMoving)
            {
                Position = Move(Position, _nextTilePosition, ScalableGameTime.DeltaTime, Speed);
            }

            // If reached the specified goal tiles, then game manager set game state to Win
            if (_currentTile != null && _currentTile.Col == 0 && (_currentTile.Row >= 46 && _currentTile.Row <= 48))
            {
                GameManager gameManager = _game.GameManager;
                gameManager.SetState(GameManager.GameState.Win, "You Win!");
            }

            AnimatedSprite.Update(ScalableGameTime.GameTime);
        }

        public override void Draw()
        {
            _game.SpriteBatch.Begin();

            if (_circleTexture != null)
            {
                Vector2 circlePosition = Position - new Vector2(_circleRadius - _tileSize / 2, _circleRadius - _tileSize / 2);
                Rectangle destinationRectangle = new Rectangle((int)circlePosition.X, (int)circlePosition.Y, _circleRadius * 2, _circleRadius * 2);
                _game.SpriteBatch.Draw(_circleTexture, destinationRectangle, Color.White * 0.3f);
            }

            _game.SpriteBatch.Draw(AnimatedSprite.TextureRegion.Texture, Position, 
                AnimatedSprite.TextureRegion.Bounds, Color.White, 0f, Origin, Scale, _spriteEffects, 0f);

            _game.SpriteBatch.End();
        }

        private Direction GetDirectionFromInput()
        {
            KeyboardState keyboardState = Keyboard.GetState();
            if (keyboardState.IsKeyDown(Keys.W)) return Direction.Up;
            else if (keyboardState.IsKeyDown(Keys.S)) return Direction.Down;
            else if (keyboardState.IsKeyDown(Keys.A)) return Direction.Left;
            else if (keyboardState.IsKeyDown(Keys.D)) return Direction.Right;
            else return Direction.None;
        }

        private void UpdateDirection(Direction newDirection)
        {
            if (newDirection != Direction.None)
            {
                if (_currentDirection == Direction.None)
                {
                    _currentDirection = newDirection;
                    _isMoving = true;
                }
                else if (_prevDirection == Direction.None && newDirection != _currentDirection)
                {
                    _prevDirection = _currentDirection;
                    _currentDirection = newDirection;
                    _isMoving = true;
                }
            }
            else
            {
                _isMoving = false;
                _currentDirection = Direction.None;
                _prevDirection = Direction.None;
                AnimatedSprite.SetAnimation("player_idleRight"); // Stop moving, use idle animation
            }
        }

        // Get next tile of at most one difference so it doesnt go diagonally
        private Tile GetNextTileFromDirection(Direction direction)
        {
            return direction switch
            {
                Direction.Up => new Tile(_currentTile.Col, _currentTile.Row - 1),
                Direction.Down => new Tile(_currentTile.Col, _currentTile.Row + 1),
                Direction.Left => new Tile(_currentTile.Col - 1, _currentTile.Row),
                Direction.Right => new Tile(_currentTile.Col + 1, _currentTile.Row),
                _ => _currentTile
            };
        }

        private Vector2 Move(Vector2 src, Vector2 dest, float elapsedSeconds, float speed)
        {
            Vector2 dP = dest - src;
            float distance = dP.Length();
            float step = speed * elapsedSeconds;

            if (step < distance)
            {
                dP.Normalize();
                return src + (dP * step);
            }
            return dest;
        }

        private void UpdateAnimatedSprite(Tile currTile, Tile nextTile)
        {
            if (currTile == null || nextTile == null)
                throw new ArgumentNullException("UpdateAnimatedSprite(): NULL in current tile or next tile.");

            int rowDiff = nextTile.Row - currTile.Row;
            int colDiff = nextTile.Col - currTile.Col;

            string animationName;
            bool isMoving = _isMoving;

            if (rowDiff == 0) // Horizontal movement
            {
                if (colDiff > 0) // Right
                {
                    animationName = isMoving ? "player_runRight" : "player_idleRight";
                    _spriteEffects = SpriteEffects.None;
                }
                else if (colDiff < 0) // Left (flip Right)
                {
                    animationName = isMoving ? "player_runRight" : "player_idleRight";
                    _spriteEffects = SpriteEffects.FlipHorizontally;
                }
                else // No movement
                {
                    animationName = "player_idleRight"; // Default to right, will flip if needed
                    _spriteEffects = SpriteEffects.None; // Default to no flip, adjust based on last direction
                }
            }
            else // Vertical movement
            {
                if (rowDiff > 0) // Down
                {
                    animationName = isMoving ? "player_runDown" : "player_idleDown";
                }
                else // Up
                {
                    animationName = isMoving ? "player_runUp" : "player_idleUp";
                }
                // Maintain last horizontal flip state for vertical movement (no flip)
                _spriteEffects = SpriteEffects.None; // No flip for Up/Down, but maintain last flip if coming from Left/Right
            }

            if (AnimatedSprite.CurrentAnimation != animationName)
            {
                AnimatedSprite.SetAnimation(animationName);
                AnimatedSprite.TextureRegion = SpriteSheet.TextureAtlas[AnimatedSprite.Controller.CurrentFrame];
            }
        }

        private void GenerateCircleTexture()
        {
            int tilesRadius = _isRunning ? 5 : 3;
            int tilesDiameter = tilesRadius * 2 + 1;
            int pixelDiameter = tilesDiameter * _tileSize;

            _circleTexture = new Texture2D(_game.GraphicsDevice, pixelDiameter, pixelDiameter);

            Color[] colorData = new Color[pixelDiameter * pixelDiameter];
            Vector2 center = new Vector2(pixelDiameter / 2, pixelDiameter / 2);
            float radius = (tilesRadius + 0.5f) * _tileSize;

            for (int y = 0; y < pixelDiameter; y++)
            {
                for (int x = 0; x < pixelDiameter; x++)
                {
                    Vector2 pos = new Vector2(x, y);
                    float distance = Vector2.Distance(center, pos);
                    colorData[y * pixelDiameter + x] = (distance <= radius) ? Color.White : Color.Transparent;
                }
            }

            _circleTexture.SetData(colorData);
        }
    }
}