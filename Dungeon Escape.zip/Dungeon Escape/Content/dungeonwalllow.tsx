<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="dungeonwalllow" tilewidth="16" tileheight="16" tilecount="48" columns="12">
 <image source="atlas_walls_low-16x16.png" trans="222222" width="192" height="64"/>
</tileset>
