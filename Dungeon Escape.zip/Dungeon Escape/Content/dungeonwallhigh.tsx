<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="dungeonwallhigh" tilewidth="16" tileheight="32" tilecount="96" columns="24">
 <image source="atlas_walls_high-16x32.png" width="384" height="128"/>
</tileset>
