<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="dungeonfloor" tilewidth="16" tileheight="16" tilecount="49" columns="7">
 <image source="atlas_floor-16x16.png" width="112" height="112"/>
</tileset>
