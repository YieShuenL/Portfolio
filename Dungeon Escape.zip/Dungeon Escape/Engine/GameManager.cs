﻿using DungeonGame;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Diagnostics;

namespace GAlgoT2430.Engine
{
    public class GameManager
    {
        public enum GameState { Running, Paused, Win, Lose }
        public GameState CurrentState;

        private SpriteFont _font;
        private GameEngine _game;
        private string _message = "";

        public GameManager(GameEngine game)
        {
            _game = game;
            CurrentState = GameState.Running;
        }

        public void LoadContent()
        {
            _font = _game.Content.Load<SpriteFont>("Arial");
        }

        public void Update()
        {
            KeyboardState keyboardState = Keyboard.GetState();
            if (keyboardState.IsKeyDown(Keys.R))
            {
                Retry();
            }
        }

        public void SetState(GameState state, string message = "")
        {
            CurrentState = state;
            _message = message;
            if (state == GameState.Paused || state == GameState.Win || state == GameState.Lose)
            {
                ScalableGameTime.TimeScale = 0f; // Pause the game by stopping time scaling
            }
            else
            {
                ScalableGameTime.TimeScale = 1f; // Resume normal time
            }
        }

        public void Draw()
        {
            _game.SpriteBatch.Begin();
            if (CurrentState != GameState.Running)
            {
                // Draw the message centered on the screen
                if (_font != null)
                {
                    Vector2 textSize = _font.MeasureString(_message);
                    Vector2 position = new Vector2(
                        (_game.Graphics.PreferredBackBufferWidth - textSize.X) / 2,
                        (_game.Graphics.PreferredBackBufferHeight - textSize.Y) / 2
                    );
                    _game.SpriteBatch.DrawString(_font, _message, position, Color.White);
                }
            }
            _game.SpriteBatch.End();
        }

        // Method to handle retry
        public void Retry()
        {
            // Reset game state
            CurrentState = GameState.Running;
            ScalableGameTime.TimeScale = 1f;
            _message = "";

            // Reset game objects
            ResetGameObjects();
        }

        private void ResetGameObjects()
        {
            // Reset Player position and state
            Player player = (Player)GameObjectCollection.FindByName("Player");
            if (player != null)
            {
                player.Initialize(); // Reinitialize to starting position and state
            }

            // Reset Guards
            foreach (var obj in GameObjectCollection.Objects.Values)
            {
                if (obj is Guard guard)
                {
                    guard.Initialize(); // Reinitialize to starting position and state
                }
            }

            // Reset Watchers
            foreach (var obj in GameObjectCollection.Objects.Values)
            {
                if (obj is Watcher watcher)
                {
                    watcher.Initialize(); // Reinitialize to starting position and state
                }
            }

            // Optionally reset other game objects or map state if needed
        }
    }
}