﻿
namespace GAlgoT2430.Engine
{
    public struct CollisionInfo
    {
        public ICollidable Other;
    }
}
