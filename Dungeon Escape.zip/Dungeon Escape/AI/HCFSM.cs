﻿
namespace GAlgoT2430.AI
{
    public abstract class HCFSM
    {
        public virtual void Initialize() { }
        public virtual void Update() { }
    }
}
