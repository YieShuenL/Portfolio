﻿using GAlgoT2430.AI;
using GAlgoT2430.Engine;
using Microsoft.Xna.Framework;
using MonoGame.Extended.Tiled;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace DungeonGame
{
    public class WatcherHCFSM : HCFSM
    {
        public enum State { Roam, Alert } // Watcher states
        public State CurrentState;

        private readonly GameEngine _game;
        private readonly Watcher _watcher;
        private readonly TiledMap _tiledMap;
        private readonly TileGraph _tileGraph;
        private readonly Player _player;
        private readonly Guard[] _guardsToAlert;

        private Tile _currentTile;
        private LinkedList<Tile> _path;
        private float _roamTimer = 3.0f; // Timer for roaming

        public WatcherHCFSM(GameEngine game, Watcher watcher, TiledMap map, TileGraph graph, Player player, Guard[] guardsToAlert)
        {
            _game = game;
            _watcher = watcher;
            _tiledMap = map;
            _tileGraph = graph;
            _player = player;
            _guardsToAlert = guardsToAlert;
            Debug.WriteLine($"Watcher initialized with {_guardsToAlert.Length} guards to alert.");
        }

        public override void Initialize()
        {
            // Start in Roam state
            CurrentState = State.Roam;
            _currentTile = Tile.ToTile(_watcher.Position, _tiledMap.TileWidth, _tiledMap.TileHeight);

            if (!_tileGraph.Nodes.Contains(_currentTile))
            {
                _currentTile = FindNearestNavigableTile(_currentTile.Col, _currentTile.Row);
                _watcher.Position = Tile.ToPosition(_currentTile, _tiledMap.TileWidth, _tiledMap.TileHeight);
                Debug.WriteLine($"Watcher initial tile invalid. Moved to {_currentTile}");
            }

            _path = GenerateRandomPath();
            Debug.WriteLine("WatcherHCFSM Initialized with roaming path!");
        }

        public override void Update()
        {
            switch (CurrentState)
            {
                case State.Roam:
                    Roam();
                    CheckPlayerDetection(); // Check if Player is detected
                    break;
                case State.Alert:
                    Alert(); // Alert behavior
                    break;
            }

            // Update animation based on movement
            Tile nextTile = (_path != null && _path.Count > 0) ? _path.First.Value : _currentTile;
            _watcher.UpdateAnimatedSprite(_currentTile, nextTile);

            float overlapRadius = 20f;
            float distance = Vector2.Distance(_watcher.Position, _player.Position);

            // If Player collided with Watcher then game manager set game state to Lose
            if (distance <= overlapRadius)
            {
                GameManager gameManager = _game.GameManager;
                gameManager.SetState(GameManager.GameState.Lose, "You Lose!");
            }
        }

        private void Roam()
        {
            _roamTimer -= ScalableGameTime.DeltaTime;
            if (_roamTimer <= 0 || _path == null || _path.Count == 0)
            {
                _path = GenerateRandomPath();
                _roamTimer = 3.0f;
            }
            MoveAlongPath();
        }

        private void Alert()
        {
            if (!IsPlayerWithinRadius())
            {
                CurrentState = State.Roam; // Return to Roam if player is out of range
                _path = GenerateRandomPath();
                _roamTimer = 3.0f;
                //Debug.WriteLine("Watcher lost Player, back to Roam");
            }
            else
            {
                AlertGuards(); // Alert nearby guards
            }
        }

        private void MoveAlongPath()
        {
            if (_path == null || _path.Count == 0) return;

            Tile nextTile = _path.First.Value;
            Vector2 nextPosition = Tile.ToPosition(nextTile, _tiledMap.TileWidth, _tiledMap.TileHeight);

            _watcher.Position = _watcher.Move(_watcher.Position, nextPosition, ScalableGameTime.DeltaTime);

            if (_watcher.Position.Equals(nextPosition))
            {
                _path.RemoveFirst();
                _currentTile = nextTile;
                //Debug.WriteLine($"Watcher reached tile: {nextTile}");
            }
        }

        private LinkedList<Tile> GenerateRandomPath()
        {
            // Generate a random path for roaming
            Tile randomTile;
            int attempts = 0;
            do
            {
                randomTile = new Tile(_game.Random.Next(0, _tiledMap.Width), _game.Random.Next(0, _tiledMap.Height));
                attempts++;
                if (attempts > 10)
                {
                    Debug.WriteLine("Watcher failed to find valid random tile after 10 attempts!");
                    return null;
                }
            } while (!_tileGraph.Nodes.Contains(randomTile));

            if (!_tileGraph.Nodes.Contains(_currentTile))
            {
                _currentTile = FindNearestNavigableTile(_currentTile.Col, _currentTile.Row);
                _watcher.Position = Tile.ToPosition(_currentTile, _tiledMap.TileWidth, _tiledMap.TileHeight);
                Debug.WriteLine($"⚠️ Current tile invalid in GenerateRandomPath. Moved to {_currentTile}");
            }

            var path = AStar.Compute(_tileGraph, _currentTile, randomTile, AStarHeuristic.Manhattan);
            if (path != null && path.Count > 0) path.RemoveFirst();
            if (path == null) Debug.WriteLine("⚠️ Watcher A* failed to generate random path!");
            return path;
        }

        private void CheckPlayerDetection()
        {
            // Check if player is within detection radius
            float distanceToPlayer = Vector2.Distance(_watcher.Position, _player.Position);
            if (IsPlayerWithinRadius())
            {
                // Switch to Alert state
                CurrentState = State.Alert;
                _path = null;
                AlertGuards();
                Debug.WriteLine("Watcher detected Player, entering Alert state!");
            }
        }

        // Check if Player within detection radius
        private bool IsPlayerWithinRadius()
        {
            float distance = Vector2.Distance(_watcher.Position, _player.Position);
            return distance <= _player.CircleRadius;
        }

        // Call nearby Guards
        private void AlertGuards()
        {
            // Check if there is any guards nearby
            if (_guardsToAlert.Length == 0)
            {
                Debug.WriteLine("No guards assigned to Watcher for alerting!");
                return;
            }

            Tile alertPosition = Tile.ToTile(_watcher.Position, _tiledMap.TileWidth, _tiledMap.TileHeight);
            float alertRadius = _watcher.GetAlertRadius();
            int alertedCount = 0;

            foreach (Guard guard in _guardsToAlert)
            {
                // No guard
                if (guard == null)
                {
                    Debug.WriteLine("No guard in _guardsToAlert array!");
                    continue;
                }

                float distanceToGuard = Vector2.Distance(_watcher.Position, guard.Position);
                Debug.WriteLine($"Checking guard at {guard.Position} (distance: {distanceToGuard}, alert radius: {alertRadius})");

                // Check if any guard inside watcher radius
                if (distanceToGuard <= alertRadius)
                {
                    if (guard.FSM is GuardHCFSM guardFSM)
                    {
                        // Don't call if guard is in Chase state
                        if (guardFSM.CurrentState == GuardHCFSM.State.Chase)
                        {
                            Debug.WriteLine($"Skipping guard at {guard.Position}: Already in Chase state!");
                            continue;
                        }

                        // Call guard to come to position
                        guardFSM.ForceChaseToPosition(alertPosition);
                        alertedCount++;
                        Debug.WriteLine($"Alerted guard at {guard.Position} to move to {alertPosition} and start chasing!");
                    }
                    else
                    {
                        Debug.WriteLine($"Guard FSM is not GuardHCFSM: {guard.FSM?.GetType().Name}");
                    }
                }
            }

            Debug.WriteLine($"Watcher forced {alertedCount} guards to chase within {alertRadius} pixels to position {alertPosition}");
        }

        private Tile FindNearestNavigableTile(int col, int row)
        {
            for (int r = 0; r < _tiledMap.Height; r++)
            {
                for (int c = 0; c < _tiledMap.Width; c++)
                {
                    Tile tile = new Tile(c, r);
                    if (_tileGraph.Nodes.Contains(tile))
                    {
                        return tile;
                    }
                }
            }
            throw new Exception("No navigable tiles found in the map!");
        }

        private Guard[] FindNearbyGuard()
        {
            List<Guard> nearbyGuard = new List<Guard>();

            foreach (var obj in GameObjectCollection.Objects.Values)
            {
                // Find nearby guard
                if (obj is Guard guard)
                {
                    float distance = Vector2.Distance(_watcher.Position, guard.Position);
                    if (distance <= _watcher.GetAlertRadius()) // add into queue if nearby have guard
                    {
                        nearbyGuard.Add(guard);
                        Debug.WriteLine($"Guard {guard.Name} is within alert range!");
                    }
                }
            }

            return nearbyGuard.ToArray();
        }
    }
}