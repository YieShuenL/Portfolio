﻿using GAlgoT2430.Engine;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MonoGame.Extended.Tiled;
using GAlgoT2430.AI;
using System;

namespace DungeonGame
{
    public class Guard : AnimationGameObject
    {
        public float MaxSpeed;

        public int StartColumn;
        public int StartRow;

        public TiledMap TiledMap;
        public TileGraph TileGraph;
        private int _tileSize = 16;

        public HCFSM FSM;

        public enum Direction { None, Up, Down, Left, Right }
        private Direction _lastDirection = Direction.Right; // Default to Right for initial state

        private Player _player;
        private SpriteEffects _spriteEffects = SpriteEffects.None; // To flip animated sprite

        public Guard() : base("enemy.sf")
        {
        }

        public override void Initialize()
        {
            GameMap gameMap = (GameMap)GameObjectCollection.FindByName("GameMap");
            TiledMap = gameMap.TiledMap;
            TileGraph = gameMap.TileGraph;
            MaxSpeed = 80.0f;

            Tile startTile = new Tile(StartColumn, StartRow);
            // Position at the center of the starting tile, adjusted for 16x16 sprite
            Position = Tile.ToPosition(startTile, TiledMap.TileWidth, TiledMap.TileHeight) + new Vector2(_tileSize / 2, _tileSize / 2);

            AnimatedSprite.SetAnimation("guard_idleRight"); // Initialize to idle animation
            AnimatedSprite.TextureRegion = SpriteSheet.TextureAtlas[AnimatedSprite.Controller.CurrentFrame];
            Origin = new Vector2(0, AnimatedSprite.TextureRegion.Bounds.Height / 2); // Had to change to 0 width, not sure why

            // Initialize Player reference and FSM
            _player = (Player)GameObjectCollection.FindByName("Player");
            FSM = new GuardHCFSM(_game, this, TiledMap, TileGraph, _player); 
            FSM.Initialize();
        }

        public override void Update()
        {
            if (FSM is GuardHCFSM fsm)
            {
                fsm.Update();

                // Ensure animation updates after FSM updates movement
                AnimatedSprite.Update(ScalableGameTime.GameTime);
            }
        }

        public override void Draw()
        {
            _game.SpriteBatch.Begin();

            // Draw with sprite effects for flipping
            _game.SpriteBatch.Draw(AnimatedSprite.TextureRegion.Texture, Position,
                AnimatedSprite.TextureRegion.Bounds, Color.White, 0f, Origin, Scale, _spriteEffects, 0f);

            _game.SpriteBatch.End();
        }

        public Vector2 Move(Vector2 src, Vector2 dest, float elapsedSeconds)
        {
            Vector2 dP = dest - src;
            float distance = dP.Length();
            float step = MaxSpeed * elapsedSeconds;

            if (step < distance)
            {
                dP.Normalize();
                return src + (dP * step);
            }
            else
            {
                return dest;
            }
        }

        public void UpdateAnimatedSprite(Tile currentTile, Tile nextTile)
        {
            if (currentTile == null || nextTile == null)
            {
                throw new ArgumentNullException("UpdateAnimatedSprite(): currentTile or nextTile is null.");
            }

            int rowDiff = nextTile.Row - currentTile.Row;
            int colDiff = nextTile.Col - currentTile.Col;

            string animationName;
            if (rowDiff == 0 && colDiff == 0) // No movement
            {
                animationName = "guard_idleRight"; // Default to right, will flip if needed
                _spriteEffects = _lastDirection == Direction.Left ? SpriteEffects.FlipHorizontally : SpriteEffects.None; // Use last direction for idle
            }
            else // Movement
            {
                if (rowDiff == 0) // Horizontal movement
                {
                    if (colDiff > 0) // Right
                    {
                        animationName = "guard_runRight";
                        _spriteEffects = SpriteEffects.None;
                    }
                    else // Left (flip Right)
                    {
                        animationName = "guard_runRight";
                        _spriteEffects = SpriteEffects.FlipHorizontally;
                    }
                }
                else // Vertical movement
                {
                    if (rowDiff > 0) // Down
                    {
                        animationName = "guard_runDown";
                    }
                    else // Up
                    {
                        animationName = "guard_runUp";
                    }
                    // Maintain last horizontal flip state for vertical movement (no flip)
                    _spriteEffects = _lastDirection == Direction.Left ? SpriteEffects.FlipHorizontally : SpriteEffects.None; // Use last horizontal direction
                }
            }

            if (AnimatedSprite.CurrentAnimation != animationName)
            {
                AnimatedSprite.SetAnimation(animationName);
                AnimatedSprite.TextureRegion = SpriteSheet.TextureAtlas[AnimatedSprite.Controller.CurrentFrame];
            }
        }

        public void SetLastDirection(Direction direction)
        {
            _lastDirection = direction;
        }

    }
}