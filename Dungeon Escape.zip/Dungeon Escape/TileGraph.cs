﻿using MonoGame.Extended.Tiled;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DungeonGame
{
    public class TileGraph
    {
        public HashSet<Tile> Nodes;
        public Dictionary<Tile, ulong[]> Connections;

        public TileGraph()
        {
            Nodes = new HashSet<Tile>();
            Connections = new Dictionary<Tile, ulong[]>();
        }

        public void CreateFromTiledMapTileLayer(TiledMapTileLayer walkLayer, ushort colStart, ushort rowStart)
        {
            bool hasTile = walkLayer.TryGetTile(colStart, rowStart, out TiledMapTile? tile);

            if (hasTile && !tile.Value.IsBlank)
            {
                BFSConstructGraph(walkLayer, colStart, rowStart);
            }
            else
            {
                throw new Exception($"[TileGraph]: Error: No tile found in (Col = {colStart}, Row = {rowStart}).");
            }
        }

        private void BFSConstructGraph(TiledMapTileLayer walkLayer, ushort colStart, ushort rowStart)
        {
            int[] MoveRow = { -1, -1, -1, 0, 0, 1, 1, 1 };
            int[] MoveCol = { -1, 0, 1, -1, 1, -1, 0, 1 };
            ulong[] Cost = { 2, 1, 2, 1, 1, 2, 1, 2 }; // Diagonal = 2, Non-Diagonal = 1
            int[] Direction = { 1, 3, 4, 6 }; // (Up = 1, Left = 3, Right = 4, Down = 6)

            Tile startTile = new Tile(colStart, rowStart);
            Nodes.Add(startTile);

            Queue<Tile> queue = new Queue<Tile>();
            queue.Enqueue(startTile);

            while (queue.Count > 0)
            {
                Tile currentTile = queue.Dequeue();

                foreach (int direction in Direction)
                {
                    int rowNeighbour = currentTile.Row + MoveRow[direction];
                    int colNeighbour = currentTile.Col + MoveCol[direction];

                    if ((0 <= rowNeighbour && rowNeighbour < walkLayer.Height) &&
                        (0 <= colNeighbour && colNeighbour < walkLayer.Width) &&
                        walkLayer.TryGetTile((ushort)colNeighbour, (ushort)rowNeighbour, out TiledMapTile? neighbourTiledMapTile) &&
                        !neighbourTiledMapTile.Value.IsBlank)
                    {
                        // Add neighbour node and its connections to graph
                        Tile neighbourTile = new Tile(colNeighbour, rowNeighbour);

                        // If neighbour node not yet created or does not exist yet.
                        if (!Nodes.Contains(neighbourTile))
                        {
                            // Add neighbour tile to the graph (this also marks it as visited)
                            Nodes.Add(neighbourTile);

                            // Add neighbour to queue
                            queue.Enqueue(neighbourTile);
                        }

                        // Create a new connection joining the current node with the neighbour node
                        if (!Connections.TryGetValue(currentTile, out ulong[] weights))
                        {
                            weights = new ulong[Cost.Length]; // Allocate 8 ulongs
                            weights[direction] = Cost[direction];
                            Connections.Add(currentTile, weights);
                        }
                        else
                        {
                            Connections[currentTile][direction] = Cost[direction];
                        }
                    }
                }
            }
        }
    }
}
