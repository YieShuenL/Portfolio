﻿using var game = new GAlgoT2430.Engine.GameEngine("Dungeon Game", 800,800);
game.AddScene("DungeonScene", new DungeonGame.DungeonScene());
game.Run();
